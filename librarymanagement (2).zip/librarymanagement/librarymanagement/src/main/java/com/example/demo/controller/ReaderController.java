package com.example.demo.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dto.PasswordDTO;
import com.example.demo.model.LoginRequest;
import com.example.demo.model.Readers;
import com.example.demo.repository.BookRepository;
import com.example.demo.repository.IssueRepository;
import com.example.demo.repository.ReaderRepository;
import com.example.demo.repository.ReserveRepository;
import com.example.demo.serviceimpl.ReaderLoginServiceImpl;
import com.example.demo.serviceimpl.Readersinterface;

@RestController
@RequestMapping("/reader/api")
@CrossOrigin(origins = "http://localhost:4200")
public class ReaderController {

    @Autowired
    private Readersinterface readerinterface;

    @Autowired
    private ReaderLoginServiceImpl loginService;

    @Autowired
    private ReaderRepository readerRepo;
    
    @Autowired
    private IssueRepository issueRepo;

    @Autowired
    private ReserveRepository reserveRepo;

    @Autowired
    private BookRepository bookRepo;


    // --------------------------------------------------------
    // ✔ REGISTER READER or LIBRARIAN (same table)
    // --------------------------------------------------------
    @PostMapping
    public ResponseEntity<?> saveReader(@RequestBody Readers reader) {

        try {
            // Default role if not provided → READER
            if (reader.getRole() == null) {
                reader.setRole(Readers.Role.READER);
            }

            Readers saved = readerinterface.saveReader(reader);
            return new ResponseEntity<>(saved, HttpStatus.CREATED);

        } catch (RuntimeException ex) {

            if ("EmailExists".equals(ex.getMessage())) {
                return ResponseEntity.status(HttpStatus.CONFLICT).body("Email already exists");
            }
            if ("NameExists".equals(ex.getMessage())) {
                return ResponseEntity.status(410).body("Reader name already exists");
            }

            return ResponseEntity.status(500).body("Registration failed");
        }
    }

    // --------------------------------------------------------
    // ✔ LOGIN FOR BOTH READER & LIBRARIAN
    // --------------------------------------------------------
    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody LoginRequest request) {

        Readers user = readerinterface.findReaderByName(request.getReaderName());

        if (user == null) {
            return ResponseEntity.status(401).body("Invalid username");
        }

        if (!user.getPassword().equals(request.getPassword())) {
            return ResponseEntity.status(401).body("Invalid password");
        }

        // Return role so Angular can redirect properly
        return ResponseEntity.ok(
                Map.of(
                        "role", user.getRole().name(),
                        "readerId", user.getReaderId(),
                        "readerName", user.getReaderName(),
                        "message", "Login successful"
                )
        );
    }

    // --------------------------------------------------------
    // ✔ GET ALL READERS (includes librarians)
    // --------------------------------------------------------
    @GetMapping
    public List<Readers> getAllReaders() {
        return readerinterface.getAllReaders();
    }

    // --------------------------------------------------------
    // ✔ GET BY ID
    // --------------------------------------------------------
    @GetMapping("/{readerId}")
    public Readers getReaderByReaderId(@PathVariable int readerId) {
        return readerinterface.getReaderByReaderId(readerId);
    }

    // --------------------------------------------------------
    // ✔ UPDATE READER
    // --------------------------------------------------------
    @PutMapping("/{readerId}")
    public Readers updateReaderByReaderId(@PathVariable int readerId,
                                          @RequestBody Readers reader) {
        return readerinterface.updateReaderByReaderId(readerId, reader);
    }

    // --------------------------------------------------------
    // ✔ DELETE READER
    // --------------------------------------------------------
    @DeleteMapping("/{readerId}")
    public String deleteReaderByReaderId(@PathVariable int readerId) {
        readerinterface.deleteReaderById(readerId);
        return "Reader deleted successfully " + readerId;
    }

    @DeleteMapping("/findAllReaders/{readerId}")
    public List<Readers> deleteReaderAndGetList(@PathVariable int readerId) {
        return readerinterface.getReaderListAfterDeleteById(readerId);
    }

    // --------------------------------------------------------
    // ✔ SEARCH BY NAME
    // --------------------------------------------------------
    @GetMapping("/findbyname/{name}")
    public List<Readers> findReaderByName(@PathVariable("name") String readerName) {
        return readerinterface.searchByReaderNameContaining(readerName);
    }

    // --------------------------------------------------------
    // ✔ SEARCH BY EMAIL
    // --------------------------------------------------------
    @GetMapping("/findbyemail/{email}")
    public Readers findReaderByEmail(@PathVariable String email) {
        return readerinterface.findReaderByEmail(email);
    }

    // --------------------------------------------------------
    // ✔ GET ONLY READERS (NOT LIBRARIANS)
    // --------------------------------------------------------
    @GetMapping("/readers-only")
    public List<Readers> getOnlyReaders() {
        return readerRepo.findByRole(Readers.Role.READER);
    }

    // --------------------------------------------------------
    // ✔ GET ONLY LIBRARIANS (OPTIONAL)
    // --------------------------------------------------------
    @GetMapping("/librarians-only")
    public List<Readers> getOnlyLibrarians() {
        return readerRepo.findByRole(Readers.Role.LIBRARIAN);
    }
    
    @PutMapping("/update-password/{readerId}")
    public ResponseEntity<?> updatePassword(
            @PathVariable int readerId,
            @RequestBody PasswordDTO dto) {

        Readers user = readerRepo.findById(readerId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!user.getPassword().equals(dto.getOldPassword())) {
            return ResponseEntity.status(400).body("Old password is incorrect");
        }

        user.setPassword(dto.getNewPassword());
        readerRepo.save(user);

        return ResponseEntity.ok("Password updated successfully");
    }
 
    @GetMapping("/dashboard/{readerId}")
    public Map<String, Object> getReaderDashboard(@PathVariable int readerId) {

        // Total Issued Books (not yet returned)
        int issuedCount = issueRepo.countByReaderIdAndStatus(readerId, "ISSUED");

        // Total Reserved Books
        int reservedCount = reserveRepo.countByReaderId(readerId);

        // Available Books (all books count)
        long availableBooks = bookRepo.count();

        return Map.of(
                "issued", issuedCount,
                "reserved", reservedCount,
                "availableBooks", availableBooks
        );
    }

}
