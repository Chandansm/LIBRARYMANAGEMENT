package com.example.demo.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.exception.ResourceNotFound;
import com.example.demo.model.Book;
import com.example.demo.model.Reserve;
import com.example.demo.repository.BookRepository;
import com.example.demo.repository.ReserveRepository;

@Service
public class ReserveServiceImpl implements Reserveinterface {

    @Autowired
    private ReserveRepository reserveRepository;

    @Autowired
    private BookRepository bookRepository;

    // ✅ MAIN RESERVE METHOD (NO DUPLICATES + UPDATE STOCK)
    @Override
    @Transactional
    public Reserve saveReserve(Reserve reserve) {

        // 1️⃣ Check if same reader already reserved same book
        boolean alreadyReserved =
                reserveRepository.existsByReaderIdAndBookId(
                        reserve.getReaderId(),
                        reserve.getBookId()
                );

        if (alreadyReserved) {
            throw new DataIntegrityViolationException(
                    "You have already reserved this book"
            );
        }

        // 2️⃣ Get book
        Book book = bookRepository.findById(reserve.getBookId())
                .orElseThrow(() -> new RuntimeException("Book not found"));

        // 3️⃣ Check availability
        if (book.getCopies() <= 0) {
            throw new RuntimeException("No copies available");
        }

        // 4️⃣ Reduce available copies
        book.setCopies(book.getCopies() - 1);
        bookRepository.save(book);

        // 5️⃣ Save reservation
        return reserveRepository.save(reserve);
    }

    // ================= OTHER METHODS =================

    @Override
    public List<Reserve> getAllReserves() {
        return reserveRepository.findAll();
    }

    @Override
    public Reserve getReserveByReserveId(int reserveId) {
        return reserveRepository.findById(reserveId)
                .orElseThrow(() ->
                        new ResourceNotFound("Reserve", "reserveId", reserveId));
    }

    @Override
    public Reserve updateReserveByReserveId(int reserveId, Reserve newReserve) {

        Reserve existingReserve = getReserveByReserveId(reserveId);

        existingReserve.setReaderId(newReserve.getReaderId());
        existingReserve.setBookId(newReserve.getBookId());
        existingReserve.setReserveDate(newReserve.getReserveDate());
        existingReserve.setExpectedReturnDate(newReserve.getExpectedReturnDate());

        return reserveRepository.save(existingReserve);
    }

    @Override
    public void deleteReserveById(int reserveId) {
        getReserveByReserveId(reserveId);
        reserveRepository.deleteById(reserveId);
    }

    @Override
    public List<Reserve> getReserveListAfterDeleteById(int reserveId) {
        deleteReserveById(reserveId);
        return reserveRepository.findAll();
    }

    @Override
    public List<Reserve> findReserveByUserId(int readerId) {
        return reserveRepository.findByReaderId(readerId);
    }

    @Override
    public List<Reserve> findReserveByBookId(int bookId) {
        return reserveRepository.findByBookId(bookId);
    }
}
