package com.example.demo.controller;

import com.example.demo.dto.PasswordDTO;
import com.example.demo.model.LoginRequest;
import com.example.demo.repository.LoginRequestRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/login")
@CrossOrigin(origins = "http://localhost:4200")
public class ReaderLoginController {

    @Autowired
    private LoginRequestRepository repo;

    @PutMapping("/update-password/{id}")
    public ResponseEntity<?> updatePassword(
            @PathVariable int id,
            @RequestBody PasswordDTO dto) {

        LoginRequest user = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // check old password
        if (!user.getPassword().equals(dto.getOldPassword())) {
            return ResponseEntity.badRequest().body("Old password is incorrect");
        }

        // save new password
        user.setPassword(dto.getNewPassword());
        repo.save(user);

        return ResponseEntity.ok("Password updated successfully!");
    }
}
