package com.example.demo.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Book;
import com.example.demo.model.Issue;
import com.example.demo.model.Readers;
import com.example.demo.model.Report;
import com.example.demo.model.ReportResponse;
import com.example.demo.repository.BookRepository;
import com.example.demo.repository.IssueRepository;
import com.example.demo.repository.ReaderRepository;
import com.example.demo.repository.ReportRepository;

@Service
public class ReportServiceImpl implements Reportinterface {

    @Autowired
    private ReportRepository reportRepository;

    @Autowired
    private ReaderRepository readerRepo;

    @Autowired
    private IssueRepository issueRepo;

    @Autowired
    private BookRepository bookRepo;

    // ---------------- CRUD METHODS ----------------
    @Override
    public Report saveReport(Report report) {
        return reportRepository.save(report);
    }

    @Override
    public List<Report> getAllReports() {
        return reportRepository.findAll();
    }

    @Override
    public Report getReportByReportId(int reportId) {
        return reportRepository.findById(reportId)
                .orElseThrow(() -> new RuntimeException("Report not found"));
    }

    @Override
    public Report updateReportByReportId(int reportId, Report newReport) {
        Report r = getReportByReportId(reportId);

        r.setReaderId(newReport.getReaderId());
        r.setBookId(newReport.getBookId());
        r.setAction(newReport.getAction());
        r.setActionDate(newReport.getActionDate());

        return reportRepository.save(r);
    }

    @Override
    public void deleteReportById(int reportId) {
        reportRepository.deleteById(reportId);
    }

    @Override
    public List<Report> findReportsByReaderId(int readerId) {
        return reportRepository.findReportsByReaderId(readerId);
    }

    @Override
    public List<Report> findReportsByBookId(int bookId) {
        return reportRepository.findReportsByBookId(bookId);
    }

    @Override
    public List<Report> getReportListAfterDeleteById(int reportId) {
        deleteReportById(reportId);
        return reportRepository.findAll();
    }

    // ----------------- ⭐ MAIN REPORT LOGIC -----------------
    @Override
    public List<ReportResponse> getReaderReports() {

        List<Readers> readers = readerRepo.findAll();
        List<ReportResponse> responseList = new ArrayList<>();

        for (Readers reader : readers) {

            // Fetch all books except DELETED
            List<Issue> issuedBooks = issueRepo.findByReaderId(reader.getReaderId())
                    .stream()
                    .filter(i -> !"DELETED".equals(i.getStatus()))
                    .collect(Collectors.toList());

            // Skip if reader has no issue history at all
            if (issuedBooks.isEmpty()) {
                continue;
            }

            // Collect book names
            List<String> bookNames = issuedBooks.stream()
                    .map(i -> bookRepo.findById(i.getBookId())
                            .map(Book::getBookName)
                            .orElse(null))       // return null instead of Unknown
                    .filter(name -> name != null) // remove null values
                    .collect(Collectors.toList());


            responseList.add(new ReportResponse(
                    reader.getReaderId(),
                    reader.getReaderName(),
                    issuedBooks.size(),
                    bookNames
            ));
        }

        return responseList;
    }


}
