package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

@Entity
@Table(name = "book_table")
public class Book {

    @Id
    @GeneratedValue
    @Column(name = "bookid")
    private Integer bookId;

    @NotBlank
    @Size(max = 50)
    @Column(name = "bookname", nullable = false)
    private String bookName;

    @NotBlank
    @Size(max = 40)
    @Column(name = "author", nullable = false)
    private String author;

    @NotBlank
    @Size(max = 30)
    @Column(name = "category", nullable = false)
    private String category;

    @Column(name = "publishername", length = 40)
    private String publisherName;

    @Min(1500)
    @Max(2025)
    @Column(name = "publishyear")
    private Integer publishYear;   // MUST BE Integer

    @Column(name = "image_url")
    private String imageUrl;
    
    @Column(name = "copies")
    private Integer copies = 5;

    public Integer getCopies() {
        return copies;
    }

    public void setCopies(Integer copies) {
        this.copies = copies;
    }

    // ---------- Getters & Setters ----------
    public Integer getBookId() { return bookId; }
    public void setBookId(Integer bookId) { this.bookId = bookId; }

    public String getBookName() { return bookName; }
    public void setBookName(String bookName) { this.bookName = bookName; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getPublisherName() { return publisherName; }
    public void setPublisherName(String publisherName) { this.publisherName = publisherName; }

    public Integer getPublishYear() { return publishYear; }
    public void setPublishYear(Integer publishYear) { this.publishYear = publishYear; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
}
