package com.example.demo.repository;

import java.io.Reader;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.model.Readers;

public interface ReaderRepository extends JpaRepository<Readers, Integer> {

    // For login (exact match)
    Readers findByReaderName(String readerName);

    // For searching (partial match)
    List<Readers> findByReaderNameContaining(String name);

    // For registration check
    boolean existsByEmail(String email);

    boolean existsByReaderName(String readerName);

    // For finding by email
    Readers findByEmail(String email);
    
    List<Readers> findByRole(Readers.Role role);


}
