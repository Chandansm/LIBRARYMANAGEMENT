package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "login_request")
public class LoginRequest {

    @Id
    @GeneratedValue
    private int id;

    @NotBlank(message = "Reader name is required")
    @Size(min = 3, max = 40)
    @Column(nullable = false, length = 40)
    private String readerName;

    @NotBlank(message = "Password is required")
    @Size(min = 6, max = 20)
    @Column(nullable = false, length = 20)
    private String password;

    // getters & setters
    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public String getReaderName() { return readerName; }

    public void setReaderName(String readerName) { this.readerName = readerName; }

    public String getPassword() { return password; }

    public void setPassword(String password) { this.password = password; }
}
