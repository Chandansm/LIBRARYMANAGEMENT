package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "report_table")
public class Report {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "reportid")
    private int reportId;

    @NotNull(message = "Reader ID is required")
    @Positive(message = "Reader ID must be a positive number")
    @Column(name = "readerid")
    private Integer readerId;

    @NotNull(message = "Book ID is required")
    @Positive(message = "Book ID must be a positive number")
    @Column(name = "bookid")
    private Integer bookId;

    @NotBlank(message = "Action is required")
    @Size(max = 20, message = "Action must be less than 20 characters")
    @Column(name = "action", length = 20)
    private String action;

    @NotBlank(message = "Action date is required")
    @Column(name = "actiondate", length = 20)
    private String actionDate;

    public Report() {}

    public int getReportId() {
        return reportId;
    }
    public void setReportId(int reportId) {
        this.reportId = reportId;
    }

    public Integer getReaderId() {
        return readerId;
    }
    public void setReaderId(Integer readerId) {
        this.readerId = readerId;
    }

    public Integer getBookId() {
        return bookId;
    }
    public void setBookId(Integer bookId) {
        this.bookId = bookId;
    }

    public String getAction() {
        return action;
    }
    public void setAction(String action) {
        this.action = action;
    }

    public String getActionDate() {
        return actionDate;
    }
    public void setActionDate(String actionDate) {
        this.actionDate = actionDate;
    }
}
