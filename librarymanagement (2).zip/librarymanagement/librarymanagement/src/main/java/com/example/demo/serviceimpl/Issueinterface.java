package com.example.demo.serviceimpl;

import java.util.List;

import com.example.demo.dto.LastIssuedDTO;

import com.example.demo.model.Issue;

public interface Issueinterface {

    Issue saveIssue(Issue issue);

    List<Issue> getAllIssues();

    Issue getIssueByIssueId(int issueId);

    Issue updateIssueByIssueId(int issueId, Issue issue);

    void deleteIssueById(int issueId);

    List<Issue> getIssueListAfterDeleteById(int issueId);

    List<Issue> findIssueByReaderId(int readerId);  // ✔ changed

    List<Issue> findIssueByBookId(int bookId);

	List<Issue> getIssuedBooksForReader(int readerId);

	List<LastIssuedDTO> getLastIssued();

	List<Issue> getTodayIssued();
	
	List<Issue> getOverdueIssues();
	
	List<Issue> getIssuedBooksOnly(int readerId);

	

	


	
}
