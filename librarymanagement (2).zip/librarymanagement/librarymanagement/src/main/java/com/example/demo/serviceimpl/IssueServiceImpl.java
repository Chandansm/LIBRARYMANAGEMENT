package com.example.demo.serviceimpl;

import com.example.demo.dto.LastIssuedDTO;

import com.example.demo.model.Issue;
import com.example.demo.repository.IssueRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

import java.util.List;

@Service
public class IssueServiceImpl implements Issueinterface {

    @Autowired
    private IssueRepository issueRepo;

    @Override
    public Issue saveIssue(Issue issue) {
        return issueRepo.save(issue);
    }

    @Override
    public List<Issue> getAllIssues() {
        return issueRepo.findAll();
    }

    @Override
    public Issue getIssueByIssueId(int issueId) {
        return issueRepo.findById(issueId).orElse(null);
    }

    @Override
    public Issue updateIssueByIssueId(int issueId, Issue issue) {
        Issue old = issueRepo.findById(issueId).orElse(null);
        if (old != null) {
            old.setReaderId(issue.getReaderId());
            old.setBookId(issue.getBookId());
            old.setIssueDate(issue.getIssueDate());
            old.setReturnDate(issue.getReturnDate());
            old.setActualReturnDate(issue.getActualReturnDate());
            old.setStatus(issue.getStatus());
            return issueRepo.save(old);
        }
        return null;
    }

    @Override
    public void deleteIssueById(int issueId) {
        issueRepo.deleteById(issueId);
    }

    @Override
    public List<Issue> getIssueListAfterDeleteById(int issueId) {
        issueRepo.deleteById(issueId);
        return issueRepo.findAll();
    }

    @Override
    public List<Issue> getIssuedBooksForReader(int readerId) {
        return issueRepo.findByReaderId(readerId);
    }

    @Override
    public List<Issue> findIssueByReaderId(int readerId) {
        return issueRepo.findByReaderId(readerId);
    }

    @Override
    public List<Issue> findIssueByBookId(int bookId) {
        return issueRepo.findByBookId(bookId);
    }

    @Override
    public List<LastIssuedDTO> getLastIssued() {
        return issueRepo.findLastIssued();
    }

    @Override
    public List<Issue> getTodayIssued() {
        return issueRepo.findTodayIssued(LocalDate.now());
    }

    @Override
    public List<Issue> getOverdueIssues() {
        return issueRepo.findOverdue(LocalDate.now());
    }

    @Override
    public List<Issue> getIssuedBooksOnly(int readerId) {
        return issueRepo.findIssuedBooksOnly(readerId);
    }

   
 
}
