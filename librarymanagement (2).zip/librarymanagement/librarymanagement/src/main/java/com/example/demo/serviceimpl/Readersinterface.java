package com.example.demo.serviceimpl;

import java.util.List;
import com.example.demo.model.Readers;

public interface Readersinterface {

    Readers saveReader(Readers reader);

    List<Readers> getAllReaders();

    Readers getReaderByReaderId(int readerId);

    Readers updateReaderByReaderId(int readerId, Readers newReader);

    void deleteReaderById(int readerId);

    List<Readers> getReaderListAfterDeleteById(int readerId);

    // ✔ EXACT MATCH — used for LOGIN
    Readers findReaderByName(String readerName);

    // ✔ EXACT MATCH — find by email
    Readers findReaderByEmail(String email);

    // ✔ PARTIAL MATCH — used for searching (findbyname endpoint)
    List<Readers> searchByReaderNameContaining(String name);
}
